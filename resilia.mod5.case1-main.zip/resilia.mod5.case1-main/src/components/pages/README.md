# Pages

Aqui estão as páginas do site e seus CSS



A fazeres: 

- Criar Formulários específicos para cada uma das páginas. Os inputs se encontram na pasta <strong>form<strong>. 
  DICA: Reutilizar o select e o submitButton, criar apenas novos Inputs, pois os dados a serem inseridos serão diferentes. 
  Após feito isso, criar cópias dos arquivos ProjectForm.js e ProjectForm.module.css, renomeá-los e montar o formulário para as páginas específicas.
- 
